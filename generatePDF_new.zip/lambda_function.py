import boto3
import json
import uuid
import os
from datetime import datetime

s3 = boto3.client('s3')
bucket_name = "cloudappointments-pdf"

def lambda_handler(event, context):
    try:
        body = json.loads(event['body']) if isinstance(event['body'], str) else event['body']
        
        full_name = body.get("fullName", "")
        service_type = body.get("serviceType", "")
        date_time = body.get("dateTime", "")
        
        print(f"Generating PDF for: {full_name}")
        
        # יצירת HTML פשוט במקום PDF
        html_content = f"""
        <html>
        <head>
            <meta charset="UTF-8">
            <style>
                body {{ font-family: Arial, sans-serif; direction: rtl; text-align: right; }}
                .container {{ max-width: 600px; margin: 50px auto; padding: 20px; border: 1px solid #ddd; }}
                h1 {{ color: #333; text-align: center; }}
                .detail {{ margin: 10px 0; font-size: 16px; }}
                .footer {{ text-align: center; margin-top: 30px; color: #666; }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>אישור קביעת תור</h1>
                <div class="detail"><strong>שם מלא:</strong> {full_name}</div>
                <div class="detail"><strong>סוג שירות:</strong> {service_type}</div>
                <div class="detail"><strong>תאריך ושעה:</strong> {date_time}</div>
                <div class="footer">
                    <p>נשמח לראותך!</p>
                    <p>צוות CloudAppointments</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        # שמירת HTML ב-S3
        file_name = f"appointment-{str(uuid.uuid4())}.html"
        
        s3.put_object(
            Bucket=bucket_name,
            Key=file_name,
            Body=html_content,
            ContentType='text/html; charset=utf-8'
        )
        
        file_url = f"https://{bucket_name}.s3.amazonaws.com/{file_name}"
        print(f"HTML uploaded successfully: {file_url}")
        
        return {
            'statusCode': 200,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'POST,OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token'
            },
            'body': json.dumps({
                'message': 'Appointment confirmation created',
                'file_url': file_url,
                'appointmentId': file_name.replace('.html', '')
            })
        }
        
    except Exception as e:
        print("Error:", str(e))
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Methods': 'POST,OPTIONS',
                'Access-Control-Allow-Headers': 'Content-Type,Authorization,X-Amz-Date,X-Api-Key,X-Amz-Security-Token'
            },
            'body': json.dumps({'error': str(e)})
        }